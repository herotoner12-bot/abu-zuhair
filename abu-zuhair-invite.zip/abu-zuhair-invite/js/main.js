(function(){
'use strict';
var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ظهور الأقسام عند النزول */
var rev = document.querySelectorAll('.reveal');
if('IntersectionObserver' in window){
  var io = new IntersectionObserver(function(es){
    es.forEach(function(e){ if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target);} });
  },{threshold:.15, rootMargin:'0px 0px -6% 0px'});
  rev.forEach(function(el){io.observe(el)});
}else rev.forEach(function(el){el.classList.add('in')});

/* جزيئات ذهبية */
(function(){
  var c=document.getElementById('sparkles'); if(!c||reduce) return;
  var x=c.getContext('2d'), W,H,dpr=Math.min(window.devicePixelRatio||1,2), ps=[], run=true;
  function size(){W=innerWidth;H=innerHeight;c.width=W*dpr;c.height=H*dpr;x.setTransform(dpr,0,0,dpr,0,0)}
  function mk(init){return{x:Math.random()*W,y:init?Math.random()*H:H+10,r:Math.random()*1.8+.5,v:Math.random()*.35+.12,a:Math.random()*.6+.25,t:Math.random()*6.28,s:Math.random()*.02+.008}}
  size(); var n=W<640?32:60; for(var i=0;i<n;i++)ps.push(mk(true));
  addEventListener('resize',size);
  document.addEventListener('visibilitychange',function(){run=!document.hidden; if(run)loop()});
  function loop(){
    if(!run)return; x.clearRect(0,0,W,H);
    for(var i=0;i<ps.length;i++){var p=ps[i]; p.y-=p.v; p.t+=p.s; p.x+=Math.sin(p.t)*.3;
      if(p.y<-10)ps[i]=mk(false);
      var al=p.a*(.55+.45*Math.sin(p.t*6));
      x.beginPath();x.fillStyle='rgba(246,215,122,'+al+')';x.shadowColor='rgba(230,185,74,.9)';x.shadowBlur=8;
      x.arc(p.x,p.y,p.r,0,6.283);x.fill();}
    requestAnimationFrame(loop);
  }
  loop();
})();

/* لمعة عند اللمس */
if(!reduce) document.addEventListener('pointerdown',function(e){
  for(var i=0;i<7;i++){
    var s=document.createElement('span'); s.className='tap-spark';
    var a=Math.random()*6.28,d=18+Math.random()*30;
    s.style.left=e.clientX-4+'px'; s.style.top=e.clientY-4+'px';
    s.style.setProperty('--dx',Math.cos(a)*d+'px'); s.style.setProperty('--dy',Math.sin(a)*d+'px');
    document.body.appendChild(s); setTimeout(function(el){el.remove()},850,s);
  }
},{passive:true});

/* معرض الصور */
(function(){
  var items=[].slice.call(document.querySelectorAll('.g-item img')),lb=document.getElementById('lightbox'),
      img=document.getElementById('lb-img'),cur=0,sx=0;
  function show(i){cur=(i+items.length)%items.length;img.src=items[cur].src;img.alt=items[cur].alt}
  function open(i){show(i);lb.hidden=false;document.body.style.overflow='hidden';lb.querySelector('.lb-close').focus()}
  function close(){lb.hidden=true;document.body.style.overflow=''}
  items.forEach(function(im,i){im.parentNode.addEventListener('click',function(){open(i)})});
  lb.querySelector('.lb-close').addEventListener('click',close);
  lb.querySelector('.lb-next').addEventListener('click',function(){show(cur+1)});
  lb.querySelector('.lb-prev').addEventListener('click',function(){show(cur-1)});
  lb.addEventListener('click',function(e){if(e.target===lb)close()});
  document.addEventListener('keydown',function(e){if(lb.hidden)return;
    if(e.key==='Escape')close(); if(e.key==='ArrowLeft')show(cur+1); if(e.key==='ArrowRight')show(cur-1)});
  lb.addEventListener('touchstart',function(e){sx=e.touches[0].clientX},{passive:true});
  lb.addEventListener('touchend',function(e){var d=e.changedTouches[0].clientX-sx; if(Math.abs(d)>50) show(d<0?cur+1:cur-1)});
})();

/* الفيديوهات: كل فيديو مستقل */
(function(){
  var PLAY='<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>',
      PAUSE='<svg viewBox="0 0 24 24"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>',
      ON='<svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0014 7.97v8.05A4.5 4.5 0 0016.5 12zM14 3.23v2.06a7 7 0 010 13.42v2.06a9 9 0 000-17.54z"/></svg>',
      OFF='<svg viewBox="0 0 24 24"><path d="M16.5 12A4.5 4.5 0 0014 7.97v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51A8.8 8.8 0 0021 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06a8.99 8.99 0 003.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>';
  [].forEach.call(document.querySelectorAll('.video-card'),function(card){
    var v=card.querySelector('video'),bp=card.querySelector('.v-play'),bs=card.querySelector('.v-sound'),
        userPaused=false,visible=false,loaded=false;
    function ui(){bp.innerHTML=v.paused?PLAY:PAUSE;bs.innerHTML=v.muted?OFF:ON;
      bp.setAttribute('aria-pressed',String(!v.paused));bs.setAttribute('aria-pressed',String(!v.muted))}
    function load(){ if(loaded)return; loaded=true; v.preload='auto'; v.src=v.dataset.src; v.load(); }
    function tryPlay(){ if(!loaded||userPaused||!visible)return; var p=v.play(); if(p&&p.catch)p.catch(function(){}); }
    v.addEventListener('play',ui);v.addEventListener('pause',ui);v.addEventListener('volumechange',ui);
    v.addEventListener('canplay',tryPlay);
    bp.addEventListener('click',function(){ if(!loaded)load(); if(v.paused){userPaused=false;v.play().catch(function(){})}else{userPaused=true;v.pause()} });
    bs.addEventListener('click',function(){ if(!loaded)load(); v.muted=!v.muted; if(v.paused&&!userPaused)tryPlay(); });
    if('IntersectionObserver' in window){
      new IntersectionObserver(function(es){ if(es[0].isIntersecting){load();} },{rootMargin:'500px 0px'}).observe(card);
      new IntersectionObserver(function(es){ visible=es[0].isIntersecting; if(visible)tryPlay(); else if(loaded)v.pause(); },{threshold:.35}).observe(card);
    }else{load();visible=true;tryPlay()}
    document.addEventListener('pointerdown',function(){tryPlay()},{once:true,passive:true});
    ui();
  });
})();
})();
