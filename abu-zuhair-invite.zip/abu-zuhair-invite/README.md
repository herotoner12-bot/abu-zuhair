# دعوة عيد ميلاد «أبو زهير»

## هيكل الملفات
- index.html : الصفحة
- css/style.css : التصميم
- js/main.js : الحركات والمعرض والفيديو

## استبدال الملفات (نفس الاسم تماماً)
assets/images/cake.jpg           صورة الكيكة
assets/images/gallery-1.jpg ... gallery-5.jpg   الصور الخمس
assets/videos/video-1.mp4        الفيديو الأول
assets/videos/video-2.mp4        الفيديو الثاني
assets/images/video-1-poster.jpg / video-2-poster.jpg   صورة الغلاف قبل تحميل الفيديو

## النشر عبر GitHub Pages
ارفع محتويات المجلد إلى مستودع، ثم Settings > Pages > Branch: main / root.
